function tog(){
    let x = document.querySelector('.link2');
    let y = document.querySelector('.burg1');
    let b = document.querySelector('.burg2');
    let a = document.querySelector('.burg3');
    x.classList.toggle('toggle');
    y.classList.toggle('tog');
    a.classList.toggle('tog');
    b.classList.toggle('tog');
}

var updateBtns = document.getElementsByClassName('update-cart');
for (i = 0; i < updateBtns.length; i++){
    updateBtns[i].addEventListener('click', function(){
        var productId = this.dataset.product;
        var action = this.dataset.action;
        console.log('productId:', productId, 'action:', action);

        console.log('USER:', user);
        if (user == 'AnonymousUser'){
            alert('You need to login to use this feature');
            console.log('User is not authenticated');
        } else {
            updateUserOrder(productId, action);
        }
    });
}

function updateUserOrder(productId, action) {
    console.log('User is authenticated, sending data..');

    var url = '/update_item/';

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken,
        },
        body: JSON.stringify({ 'productId': productId, 'action': action })
    })
    .then((response) => {
        return response.json();
    })
    .then((data) => {
        console.log('data:', data);
        if (data == 'Out of stock') {
            showAlert('Out of stock!', 'danger');
        } else {
            // Update the cart quantity displayed on the page
            const itemQuantity = document.querySelector(`#item-quantity-${productId}`);
            const cartTotal = document.querySelector('#cart-badge');
            const cartTotalElements = document.getElementsByClassName('cart_total');
            
            if (data.item_quantity <= 0) {
                // If the quantity is zero or item is removed, remove the item from the DOM
                document.querySelector(`#cart-item-${productId}`).remove();
            } else {
                // Update the quantity displayed for this product
                itemQuantity.innerText = data.item_quantity;
            }

            // Update all elements with class 'cart_total' with the new cart total
            for (let i = 0; i < cartTotalElements.length; i++) {
                cartTotalElements[i].innerText = data.cart_total;
            }

            // Optionally, update the number of items in the cart badge
            cartTotal.innerText = data.cart_total;
            const cartBadge = document.querySelector('#cart-badge');
            cartBadge.innerText = data.cart_items_count;

            // Show a success alert when an item is added/removed
            if (action == 'add') {
                showAlert('Item added to cart!', 'success');
            } else if (action == 'remove') {
                showAlert('Item removed from cart!', 'warning');
            }
        }
    });
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} show`;
    alertDiv.textContent = message;

    // Append the alert to the body or a specific container
    document.body.appendChild(alertDiv);

    // Automatically remove the alert after 3 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 500); // Wait for fade-out transition
    }, 3000);
}